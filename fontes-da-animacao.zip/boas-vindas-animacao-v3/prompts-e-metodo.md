# Prompts finais usados na correção

## Instrumentos separados

Asset type: isolated PIXEL-ART props for cutout animation. Use input1 ONLY for the burgundy drum kit reference, input2 ONLY for keyboard and microphone hardware reference. The people are NOT to appear.
Create a transparent WIDE 2:1 sprite atlas containing EXACTLY TWO objects, safely separated:
LEFT HALF: complete compact acoustic DRUM KIT, near-front view: burgundy/red shells, large off-white bass drum front, two toms and one small snare, two gold cymbals on gray/dark stands. Empty behind drums, NO DRUMMER, NO HANDS, NO SHOES, no sticks. Full stands and feet visible. Keep reference's chunky simplified design.
RIGHT HALF: complete BLACK ELECTRONIC KEYBOARD on BLACK X support, near-front view, white/black chunky key groups, few small RED control pads at viewer-right end. ONE black boom microphone stand on viewer-LEFT of keyboard, silver grille extending toward center at singer mouth height, one loose short cable. Empty behind keyboard, NO KEYBOARDIST, NO HUMAN HANDS OR ARMS, no shoes. Complete supports and feet visible.
These are stable prop layers to animate as rigid objects: preserve familiar silhouettes/palettes from references, same coarse pixel grid for ALL details, bold stepped edges, flat limited colors, no photographic hardware, no tiny pixels, no antialiasing, no gradients, no brands, no labels, no logos. Each full object fits its own half with generous transparent padding and a large gap between the two. Do not let left and right props touch. No characters, no scenery, no floor, no shadows. TRUE TRANSPARENT BACKGROUND.

## Corpo da tecladista sem equipamento

Edit the attached approved pixel-art keyboardist into ONE clean CHARACTER-ONLY layer for skeletal animation.
Remove ALL equipment: keyboard, X support, microphone, boom stand, cables. Reconstruct the small hair/cheek areas obscured by microphone naturally. Keep the SAME woman's face, brown curly shoulder-length hair, natural warm light-medium beige skin, gray sleeveless tank top, silver necklace, black loose pants, black shoes and black wristwatch. NO GLASSES. Preserve same chibi head/body proportions and exact coarse pixel-art style, flat color clusters and dark stepped outlines. Do not make skin pale white or yellow-orange.
She stands front slight three-quarter view, full head to feet. BOTH arms relaxed forward with elbows slightly bent and hands hovering at WAIST HEIGHT as though gently playing keyboard keys (but no instrument is drawn). Hands separated to either side of torso, fingers down, simple chunky hands. No hand raised above head.
One coherent complete person only with legs and both black shoes visible. Genuine transparent background. Full hair/face unoccluded, NO microphone even near mouth, no leftover supports across trousers, no instrument outlines, no floor, no shadows, no text, no logos, no other people. Do not increase detail or pixel resolution within the character. This is a static clean source layer, not an animation sheet.

## Método

Imagens geradas com a ferramenta integrada image_gen, usando referências do projeto. Composição e animação local com recortes estáveis, articulação de pernas e mãos, trajetórias contínuas e renderização sem suavização de pixels. Não foi usada troca de folhas de sprites para interpolar os rostos.
