from movimento import *
import json
FPS=60;DURATION=32

def strip(im,s0,s1,width):
 dx,dy=s1[0]-s0[0],s1[1]-s0[1];l=math.hypot(dx,dy);px=-dy/l*width/2;py=dx/l*width/2
 ex,ey=dx/l*2,dy/l*2
 return masked(im,[(s0[0]-ex+px,s0[1]-ey+py),(s1[0]+ex+px,s1[1]+ey+py),(s1[0]+ex-px,s1[1]+ey-py),(s0[0]-ex-px,s0[1]-ey-py)])

class Walker:
 def __init__(self,name,height,hip,knee,ankle,foot,footbox,cut,extent,stride,lens):
  self.im=sprite(name,height);self.height=height;self.hip=hip;self.knee=knee;self.ankle=ankle;self.foot=foot
  self.stride=stride;self.lens=lens;self.extent=extent
  keep=Image.new('L',self.im.size);d=ImageDraw.Draw(keep);d.rectangle((0,0,self.im.width,cut),fill=255)
  if name=='voz_andando':
   d.rectangle((25,75,48,91),fill=255);d.rectangle((94,66,self.im.width,height),fill=0)
  if name=='bateria_entrada':
   a=np.asarray(self.im);skin=(a[:,:,0]>a[:,:,1]*1.12)&(a[:,:,1]>a[:,:,2]*1.15)&(a[:,:,2]>65)
   k=np.asarray(keep).copy();k[:90,:]=0;k[75:90,:]=np.where(skin[75:90,:],255,0);keep=Image.fromarray(k)
  if name=='teclado_entrada':
   d.rectangle((0,0,111,height),fill=0);d.rectangle((102,72,124,93),fill=255)
  self.upper=self.im.copy();self.upper.putalpha(Image.fromarray(np.minimum(np.asarray(self.im)[:,:,3],np.asarray(keep))))
  self.parts=[strip(self.im,hip,knee,extent),strip(self.im,knee,ankle,extent),masked(self.im,footbox)]
  self.dark=[ImageEnhance.Brightness(p).enhance(.8) for p in self.parts]
 def render(self,distance,lean=0):
  out=Image.new('RGBA',(320,260));ox,oy=65,24
  q=distance/(2*self.stride/.6);bob=-1.0*abs(math.sin(q*2*math.pi))
  for i,phase in enumerate((q+.5,q)):
   hp=(ox+self.hip[0]+(-3 if i==0 else 3),oy+self.hip[1]+bob)
   dx,dy,angle=step(phase,self.stride,min(11,self.stride*.7))
   ak=(ox+self.hip[0]+dx,oy+self.ankle[1]+dy)
   kn=ik(hp,ak,*self.lens)
   p=self.dark if i==0 else self.parts
   bone(out,p[0],self.hip,self.knee,hp,kn);bone(out,p[1],self.knee,self.ankle,kn,ak)
   bone(out,p[2],self.ankle,(self.ankle[0]+10,self.ankle[1]),ak,(ak[0]+10*math.cos(angle),ak[1]+10*math.sin(angle)))
  if lean:
   hp=(ox+self.hip[0],oy+self.hip[1]+bob)
   bone(out,self.upper,self.hip,(self.hip[0],self.hip[1]-30),hp,(hp[0]+30*math.sin(lean),hp[1]-30*math.cos(lean)))
  else:out.alpha_composite(self.upper,(ox,round(oy+bob)))
  return out,(ox+self.hip[0],oy+self.height)

VW=Walker('voz_andando',128,(55,79),(65,101),(73,117),(79,121),[(63,114),(97,114),(97,128),(63,128)],80,16,13,(24,21))
DW=Walker('bateria_entrada',192,(68,159),(73,174),(78,185),(83,188),[(69,180),(99,180),(99,192),(69,192)],161,13,12,(17,15))
KW=Walker('teclado_entrada',148,(143,93),(155,114),(166,136),(172,140),[(157,130),(183,130),(183,148),(157,148)],95,17,14,(24,24))

def clean(im):
 a=np.asarray(im).copy();a[:,:,3]=np.where(a[:,:,3]>144,255,0);return Image.fromarray(a)

atlas=clean(Image.open(ROOT/'props-atlas.png').convert('RGBA'))
dr=atlas.crop((0,0,950,atlas.height));dr=dr.crop(dr.getbbox());dr=dr.resize((148,round(dr.height*148/dr.width)),NEAREST)
kb=atlas.crop((950,0,atlas.width,atlas.height));kb=kb.crop(kb.getbbox())
ar=np.asarray(kb);white=(ar[:,:,:3].min(axis=2)>185)&(np.ptp(ar[:,:,:3].astype(int),axis=2)<65)&(ar[:,:,3]>0)
key_y=int(np.argmax(white.sum(axis=1)));scale=64/(kb.height-key_y)
kb=kb.resize((round(kb.width*scale),round(kb.height*scale)),NEAREST)
dr.save(ROOT/'bateria-fixa.png');kb.save(ROOT/'teclado-fixo.png')

def white_center(im):
 a=np.asarray(im);m=(a[:,:,:3].min(axis=2)>190)&(np.ptp(a[:,:,:3].astype(int),axis=2)<60)&(a[:,:,3]>0)
 yy,xx=np.where(m);return float(np.median(xx))
DRX=white_center(dr)
ka=np.asarray(kb);wm=(ka[:,:,:3].min(axis=2)>185)&(np.ptp(ka[:,:,:3].astype(int),axis=2)<65)&(ka[:,:,3]>0);py=int(np.argmax(wm.sum(axis=1)));yy,xx=np.where(wm[max(0,py-2):py+3]);KX=float(np.median(xx))

def person_plate(name,height,kind):
 im=sprite(name,height);a=np.asarray(im).copy();y,x=np.indices(a.shape[:2]);r,g,b=a[:,:,0].astype(float),a[:,:,1].astype(float),a[:,:,2].astype(float)
 if kind=='drums':
  mask=((x>35)&(x<118)&(y<91))|((x>18)&(x<65)&(y<53))
  gold=(r>130)&(g>75)&(b<90)&(r>g*1.12)
  gray=(np.ptp(a[:,:,:3].astype(int),axis=2)<40)&(a[:,:,:3].min(axis=2)>95)&(y>68)
  mask&=~gold&~gray
 elif kind=='keys':
  m=Image.new('L',im.size);ImageDraw.Draw(m).polygon([(45,0),(116,0),(121,88),(118,140),(40,140),(42,87),(35,69),(45,51)],fill=255)
  mask=np.asarray(m)>0
  skin=(r>g*1.1)&(g>b*1.1)&(b>75)
  mask&=~((y>=78)&(y<=91)&~skin)
  mask&=~((x<56)&(y>23)&(y<64))
  mask&=~((x>=55)&(x<=65)&(y>=32)&(y<=46)&(np.ptp(a[:,:,:3].astype(int),axis=2)<35))
 else:mask=np.ones(a.shape[:2],dtype=bool)
 a[:,:,3]=np.where(mask,a[:,:,3],0)
 return Image.fromarray(a)

GP=person_plate('guitarra_tocando',128,'guitar')
VP=person_plate('voz_cantando',128,'voice')
DP=person_plate('bateria_tocando',136,'drums')
KP=clean(Image.open(ROOT/'tecladista-corpo-base.png').convert('RGBA'))
KP=KP.crop(KP.getbbox());KP=KP.resize((round(KP.width*144/KP.height),144),NEAREST)
KP_ANCHOR=(KP.width/2,144)

MESH={}
def puppet(im,t,kind):
 # A small continuous deformation moves existing pixels. It never swaps faces.
 if kind not in MESH:
  yy,xx=np.indices((im.height,im.width),dtype=np.float32);MESH[kind]=(xx,yy)
 xx,yy=MESH[kind];sx=xx.copy();sy=yy.copy();beat=2*math.pi*2*t
 if kind=='guitar':cs=[(24,81,0,2.7*math.sin(beat*2),9,10),(66,74,.7*math.sin(beat),.5*math.cos(beat),8,8),(40,35,0,.8*math.sin(beat),35,35)]
 elif kind=='voice':cs=[(21,84,1.5*math.sin(beat*.5),2.4*math.sin(beat*.5),12,15),(86,59,0,.9*math.sin(beat),12,15),(57,35,.5*math.sin(beat*.5),.8*math.cos(beat),30,30)]
 elif kind=='drums':cs=[(35,12,-4*math.sin(beat),10*(.5+.5*math.sin(beat)),13,25),(45,43,-2*math.sin(beat),4*math.sin(beat),13,16),(114,72,0,3.5*math.sin(beat+math.pi),12,10),(89,30,0,.7*math.sin(beat),24,22)]
 else:cs=[(im.width*.16,im.height*.55,0,1.8*math.sin(beat*2),8,6),(im.width*.88,im.height*.55,0,1.8*math.sin(beat*2+math.pi),8,6),(im.width*.5,35,.5*math.sin(beat*.5),.8*math.sin(beat),29,30)]
 for cx,cy,dx,dy,rx,ry in cs:
  w=np.exp(-(((xx-cx)/rx)**2+((yy-cy)/ry)**2)*2)
  sx-=dx*w;sy-=dy*w
 sx=np.clip(np.rint(sx).astype(int),0,im.width-1);sy=np.clip(np.rint(sy).astype(int),0,im.height-1)
 return Image.fromarray(np.asarray(im)[sy,sx])

def paste(im,part,anchor,x,y,sx=1,angle=0):
 if angle:
  # Work on a padded local plane, rotating about the supplied ground anchor.
  plane=Image.new('RGBA',(360,280));plane.alpha_composite(part,(round(180-anchor[0]),round(230-anchor[1])))
  part=plane.rotate(angle,NEAREST,center=(180,230));anchor=(180,230)
 if sx!=1:
  part=part.resize((max(1,round(part.width*abs(sx))),part.height),NEAREST)
  ax=anchor[0]*abs(sx)
  if sx<0:part=part.transpose(Image.Transpose.FLIP_LEFT_RIGHT);ax=part.width-ax
  anchor=(ax,anchor[1])
 im.alpha_composite(part,(round(x-anchor[0]),round(y-anchor[1])))

def ease(q):q=max(0,min(1,q));return q*q*(3-2*q)
def travel(q):
 q=max(0,min(1,q));e=.12
 if q<e:return q*q/(2*e)/(1-e)
 if q>1-e:return 1-(1-q)**2/(2*e)/(1-e)
 return (q-e/2)/(1-e)
def turn(im,a,aa,b,ba,u,x,y):
 if u<.5:paste(im,a,aa,x,y,sx=max(.08,math.cos(u*math.pi)))
 else:paste(im,b,ba,x,y,sx=max(.08,-math.cos(u*math.pi)))

def cable(im,mx,my,bx,base,t):
 pts=[]
 # Sag beside the singer, then a trailing slack loop behind her steps.
 p0=(mx,my);p1=(mx+18,my+24);p2=(mx+10,base-2);p3=(bx-8,base-1)
 for k in range(25):
  u=k/24;v=1-u;pts.append((v**3*p0[0]+3*v*v*u*p1[0]+3*v*u*u*p2[0]+u**3*p3[0],v**3*p0[1]+3*v*v*u*p1[1]+3*v*u*u*p2[1]+u**3*p3[1]))
 for k in range(25):
  u=k/24;pts.append((bx-8-34*u,base-1+3*math.sin(u*math.pi)))
 ImageDraw.Draw(im).line(pts,fill='#263239',width=2)

def render(t):
 im=BG.copy()
 # Drummer: one body rig and one unchanged drum prop, including the fall.
 if t>=5:
  if t<9.2:
   x=-140+368*travel((t-5)/4.2);dist=x+140;p,a=DW.render(dist)
   paste(im,p,a,x,276)
   bob=-1*abs(math.sin(dist/(2*12/.6)*2*math.pi))
   paste(im,dr,(DRX,dr.height),x,175+bob)
  elif t<10.6:
   u=(t-9.2)/1.4;dist=368
   x=228+32*ease(u)
   p,a=DW.render(dist,lean=.16*math.sin(math.pi*u));paste(im,p,a,228+16*ease(u),276)
   if u<.18:bottom=175-3*math.sin(math.pi*u/.18);kx=228
   elif u<.8:
    q=(u-.18)/.62;bottom=175+101*q*q;kx=228+32*ease(q)
   else:
    q=(u-.8)/.2;bottom=276-10*math.sin(math.pi*q)**2;kx=260
   paste(im,dr,(DRX,dr.height),kx,bottom,angle=4*math.sin(u*math.pi))
  elif t<11.8:
   u=(t-10.6)/1.2;p,a=DW.render(368)
   body=puppet(DP,t,'drums')
   if u<.4:turn(im,p,a,body,(68,136),u/.4,244+16*ease(u/.4),276)
   else:paste(im,body,(68,136),260,276-18*(1-ease((u-.4)/.6)))
   paste(im,dr,(DRX,dr.height),260,276)
  else:
   paste(im,puppet(DP,t,'drums'),(68,136),260,276)
   paste(im,dr,(DRX,dr.height),260,276)
 # Keyboard rig and musician are independent: no morphing when she stops.
 if t>=16.2:
  if t<21.3:
   kx=-200+680*travel((t-16.2)/5.1);dist=kx+200
   paste(im,kb,(KX,kb.height),kx,316)
   p,a=KW.render(dist);paste(im,p,a,kx+73,316)
  elif t<23.1:
   u=(t-21.3)/1.8
   if u<.65:
    q=ease(u/.65);p,a=KW.render(680+91*q)
    sx=math.cos(math.pi*min(1,u/.24));sx=math.copysign(max(.08,abs(sx)),sx)
    paste(im,p,a,553-91*q,316,sx=sx)
   else:
    p,a=KW.render(771);p=p.transpose(Image.Transpose.FLIP_LEFT_RIGHT);a=(p.width-a[0],a[1])
    turn(im,p,a,puppet(KP,t,'keys'),KP_ANCHOR,(u-.65)/.35,462,316)
   paste(im,kb,(KX,kb.height),480,316)
  else:
   paste(im,puppet(KP,t,'keys'),KP_ANCHOR,462,316)
   paste(im,kb,(KX,kb.height),480,316)
 # Front row.
 if t>=.8:
  if t<4.4:
   x=-90+215*travel((t-.8)/3.6);p,a=GW.render(x+90);paste(im,p,a,x,322)
  elif t<4.75:
   p,a=GW.render(215);turn(im,p,a,puppet(GP,t,'guitar'),(45,128),(t-4.4)/.35,125,322)
  else:paste(im,puppet(GP,t,'guitar'),(45,128),125,322)
 if t>=12.2:
  if t<15.5:
   x=-80+425*travel((t-12.2)/3.3);p,a=VW.render(x+80)
   cable(im,x+38,326-62,x,326,t);paste(im,p,a,x,326)
  elif t<15.85:
   p,a=VW.render(425);turn(im,p,a,puppet(VP,t,'voice'),(50,128),(t-15.5)/.35,345,326)
  else:paste(im,puppet(VP,t,'voice'),(50,128),345,326)
 return im.convert('RGB')

def samples():
 out=Image.new('RGB',(960,540))
 for i,t in enumerate([2.7,7.2,9.8,11.8,14.3,18.5,22.3,27,28]):out.paste(render(t).resize((320,180),NEAREST),((i%3)*320,(i//3)*180))
 out.save(ROOT/'conferencia.png');render(28).save(ROOT/'cena-final.png')

def export():
 p=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size','1280x720','-framerate','60','-i','pipe:0','-an','-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(ROOT/'boas-vindas-movimento-continuo.mp4')],stdin=subprocess.PIPE)
 for i in range(FPS*DURATION):
  p.stdin.write(render(i/FPS).resize((1280,720),NEAREST).tobytes())
  if i%(FPS*4)==0:print(f'Video {i//FPS}/{DURATION}s',flush=True)
 p.stdin.close()
 if p.wait():raise RuntimeError('video encoder')
 palette=render(28).quantize(colors=160)
 frames=[render(i/30).quantize(palette=palette,dither=Image.Dither.NONE) for i in range(DURATION*30)]
 frames[0].save(ROOT/'previa-movimento.gif',save_all=True,append_images=frames[1:],duration=[30,30,40]*(DURATION*10),loop=0,optimize=True,disposal=1)
 print('Exports finished',flush=True)

if __name__=='__main__':
 samples()
 if '--preview' not in sys.argv:export()
