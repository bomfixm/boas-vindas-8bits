from pathlib import Path
from PIL import Image,ImageDraw,ImageEnhance
import numpy as np,math,subprocess,sys
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'boas-vindas-animacao-v1'
NEAREST=Image.Resampling.NEAREST
W,H=640,360
old=(OLD/'montar.py').read_text(encoding='utf8')
exec(old[old.index('GLYPHS='):old.index('BG=background()')],globals())
BG=background()

def sprite(name,height):
 im=Image.open(OLD/'quadros'/(name+'-01.png')).convert('RGBA')
 a=np.asarray(im).copy();a[:,:,3]=np.where(a[:,:,3]>=144,255,0)
 im=Image.fromarray(a)
 return im.resize((round(im.width*height/im.height),height),NEAREST)

def masked(im,polygon):
 mask=Image.new('L',im.size);ImageDraw.Draw(mask).polygon(polygon,fill=255)
 out=im.copy();out.putalpha(Image.fromarray(np.minimum(np.asarray(im)[:,:,3],np.asarray(mask))))
 return out

def bone(dst,im,s0,s1,d0,d1):
 sx,sy=s1[0]-s0[0],s1[1]-s0[1];dx,dy=d1[0]-d0[0],d1[1]-d0[1]
 den=sx*sx+sy*sy
 ar=(dx*sx+dy*sy)/den;ai=(dy*sx-dx*sy)/den
 tx=d0[0]-ar*s0[0]+ai*s0[1];ty=d0[1]-ai*s0[0]-ar*s0[1]
 den2=ar*ar+ai*ai
 matrix=(ar/den2,ai/den2,(-ar*tx-ai*ty)/den2,-ai/den2,ar/den2,(ai*tx-ar*ty)/den2)
 layer=im.transform(dst.size,Image.Transform.AFFINE,matrix,resample=NEAREST)
 dst.alpha_composite(layer)

def ik(h,a,l1,l2):
 dx,dy=a[0]-h[0],a[1]-h[1];dist=min(math.hypot(dx,dy),l1+l2-.001)
 actual=math.hypot(dx,dy);ux,uy=dx/actual,dy/actual
 along=(l1*l1-l2*l2+dist*dist)/(2*dist)
 perp=math.sqrt(max(0,l1*l1-along*along))
 return h[0]+ux*along+uy*perp,h[1]+uy*along-ux*perp

def step(q,a=8,up=6):
 q%=1
 if q<.6:return a-2*a*q/.6,0,0
 u=(q-.6)/.4
 return -a+2*a*(u*u*(3-2*u)),-up*math.sin(math.pi*u),-.24*math.sin(math.pi*u)

class GuitarWalk:
 def __init__(self):
  im=sprite('guitarra_andando',128);self.im=im
  keep=Image.new('L',im.size,255);d=ImageDraw.Draw(keep);d.rectangle((0,101,im.width,128),fill=0)
  d.polygon([(5,93),(37,93),(34,105),(19,112),(7,108)],fill=255)
  upper=im.copy();upper.putalpha(Image.fromarray(np.minimum(np.asarray(im)[:,:,3],np.asarray(keep))))
  self.upper=upper
  self.thigh=masked(im,[(42,97),(55,97),(64,112),(61,117),(48,116),(44,108)])
  self.shin=masked(im,[(49,108),(64,108),(64,119),(48,122)])
  self.foot=masked(im,[(47,117),(73,116),(73,128),(47,128)])
  self.dark=[ImageEnhance.Brightness(p).enhance(.8) for p in (self.thigh,self.shin,self.foot)]
 def render(self,distance):
  im=Image.new('RGBA',(200,180));ox,oy=45,22
  q=distance/(2*12/.6)
  bob=-.9*abs(math.sin(q*2*math.pi))
  for idx,phase in enumerate((q+.5,q)):
   hip=(ox+(42 if idx==0 else 48),oy+101+bob)
   dx,dy,angle=step(phase,12,9)
   ankle=(ox+45+dx,oy+121+dy)
   knee=ik(hip,ankle,14,12)
   parts=self.dark if idx==0 else [self.thigh,self.shin,self.foot]
   bone(im,parts[0],(48,100),(55,111),hip,knee)
   bone(im,parts[1],(55,111),(56,119),knee,ankle)
   bone(im,parts[2],(56,119),(66,119),ankle,(ankle[0]+10*math.cos(angle),ankle[1]+10*math.sin(angle)))
  im.alpha_composite(self.upper,(ox,round(oy+bob)))
  return im,(ox+45,oy+128)

GW=GuitarWalk()

def testframe(t):
 im=BG.copy();x=-65+190*t/4
 part,anchor=GW.render(x+65)
 im.alpha_composite(part,(round(x-anchor[0]),round(322-anchor[1])))
 return im.convert('RGB')

def test():
 cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size','1280x720','-framerate','60','-i','pipe:0','-an','-c:v','libx264','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(ROOT/'teste-caminhada.mp4')]
 p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 contact=Image.new('RGB',(960,540))
 for i in range(240):
  im=testframe(i/60)
  p.stdin.write(im.resize((1280,720),NEAREST).tobytes())
  if i in [60,80,100,120,140,160,180,200,220]:
   n=[60,80,100,120,140,160,180,200,220].index(i)
   contact.paste(im.resize((320,180),NEAREST),((n%3)*320,(n//3)*180))
 p.stdin.close()
 if p.wait():raise RuntimeError('encoder')
 contact.save(ROOT/'teste-contato.png')
 frames=[testframe(1+i/30).quantize(colors=128) for i in range(90)]
 frames[0].save(ROOT/'teste-caminhada.gif',save_all=True,append_images=frames[1:],duration=[30,30,40]*30,loop=0,optimize=True)

if __name__=='__main__':test()
