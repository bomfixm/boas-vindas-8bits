# Fontes da animação

As pastas boas-vindas-animacao-v1 e boas-vindas-animacao-v3 devem ficar lado a lado. Execute cena.py dentro da pasta v3 usando Python com Pillow e NumPy, e FFmpeg no PATH. Use --preview para gerar apenas as imagens de conferência. O arquivo montar.py da v1 fornece o cenário e o alfabeto; os quadros necessários estão incluídos.

As artes-aprovadas servem como referência de identidade. Os sprites-adicionais têm mais poses, mas precisam de revisão de consistência antes de serem usados em uma sequência. O MP4 publicado no site é o resultado de cena.py.
