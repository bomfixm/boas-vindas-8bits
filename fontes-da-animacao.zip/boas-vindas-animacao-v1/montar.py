from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import numpy as np
import subprocess, json, math, sys

ROOT = Path(__file__).resolve().parent
SRC = ROOT.parents[1] / 'assets' / 'personagens'
FRAMES = ROOT / 'quadros'
FRAMES.mkdir(parents=True, exist_ok=True)
W, H, FPS, DURATION = 640, 360, 12, 32
NEAREST = Image.Resampling.NEAREST

SPECS = {
 'guitarra_andando': ('guitarrista-sprites-v1/andando.png',6,3,1,'body',.47),
 'guitarra_tocando': ('guitarrista-sprites-v1/tocando.png',6,3,0,'body',.47),
 'bateria_entrada': ('baterista-entrada-saida-v1/01-entrada-carregando.png',4,2,None,'drums',.42),
 'bateria_queda': ('baterista-entrada-saida-v1/02-arremesso-e-impacto.png',4,2,None,'drums',.42),
 'bateria_sentar': ('baterista-entrada-saida-v1/03-sentar-e-preparar.png',4,2,None,'drums',.42),
 'bateria_tocando': ('baterista-entrada-saida-v1/04-tocando.png',4,2,None,'drums',.42),
 'voz_andando': ('cantora-sprites-v1/02-andando.png',6,3,1,'body',.47),
 'voz_cantando': ('cantora-sprites-v1/04-cantando.png',6,3,0,'body',.47),
 'teclado_entrada': ('tecladista-entrada-saida-v1/01-entrada-arrastando.png',4,2,None,'keys',.35),
 'teclado_posicionar': ('tecladista-entrada-saida-v1/02-posicionar-e-ajustar.png',4,2,None,'keys',.35),
 'teclado_tocando': ('tecladista-entrada-saida-v1/03-tocando.png',4,2,None,'keys',.35),
 'teclado_cantando': ('tecladista-entrada-saida-v1/04-cantando.png',4,2,None,'keys',.35),
}

class Frame:
 def __init__(self, im, ax, ay, scale, meta):
  self.im = im.resize((max(1,round(im.width*scale)),max(1,round(im.height*scale))),NEAREST)
  self.ax, self.ay = ax*scale, ay*scale
  self.meta = meta

GROUPS, META = {}, {}
for name,(filename,cols,rows,row,kind,scale) in SPECS.items():
 sheet = Image.open(SRC/filename).convert('RGBA')
 sw,sh = sheet.size
 arr = np.asarray(sheet).copy()
 # Discard almost-transparent generation residue; retain the drawn silhouettes.
 arr[:,:,3] = np.where(arr[:,:,3]>=144,255,0).astype(np.uint8)
 sheet = Image.fromarray(arr)
 indexes = list(range(cols*rows)) if row is None else list(range(row*cols,(row+1)*cols))
 group, entries = [], []
 for j,idx in enumerate(indexes):
  rr,cc = divmod(idx,cols)
  xs = [round(i*sw/cols) for i in range(cols+1)]
  if name=='bateria_queda':
   xs = [0,392,786,1172,sw] if rr==0 else [0,418,832,1198,sw]
  if name=='teclado_posicionar' and rr==0:
   xs=[0,460,894,1342,sw]
  box=(xs[cc],round(rr*sh/rows),xs[cc+1],round((rr+1)*sh/rows))
  cell=sheet.crop(box)
  a=np.asarray(cell)
  opaque=a[:,:,3]>0
  mass=opaque.sum(axis=1)
  ys=np.where(mass>=max(5,int(cell.width*.015)))[0]
  baseline=int(ys[-1]+1)
  bounds=cell.getbbox()
  if not bounds: raise ValueError((name,j,'empty frame'))
  ax=cell.width*.48
  frame_scale=scale
  white=opaque & (a[:,:,:3].min(axis=2)>190) & (np.ptp(a[:,:,:3].astype(np.int16),axis=2)<65)
  if kind=='drums':
   wy,wx=np.where(white)
   ax=float(np.median(wx))
  elif kind=='keys':
   rowmass=white.sum(axis=1)
   peak=int(np.argmax(rowmass))
   lo,hi=max(0,peak-5),min(cell.height,peak+7)
   wy,wx=np.where(white[lo:hi,:])
   if len(wx)<30: raise ValueError((name,j,'keyboard anchor not found'))
   ax=float(np.median(wx))
   key_width=float(np.percentile(wx,97)-np.percentile(wx,3))
   # Compensate for the different framing of the generated keybed.
   frame_scale=float(np.clip(.35*(300/max(key_width,1))**.60,.30,.48))
  # Do not recenter each pose independently: keep its equipment/body anchor.
  tight=cell.crop(bounds)
  tight.save(FRAMES/f'{name}-{j+1:02}.png')
  entry={'source':filename,'source_rect':box,'trim':bounds,'anchor':[ax-bounds[0],baseline-bounds[1]],'scale':frame_scale}
  entries.append(entry)
  group.append(Frame(tight,ax-bounds[0],baseline-bounds[1],frame_scale,entry))
 GROUPS[name]=group
 META[name]=entries

(ROOT/'quadros.json').write_text(json.dumps(META,ensure_ascii=False,indent=2),encoding='utf8')

GLYPHS={
'A':['01110','10001','10001','11111','10001','10001','10001'],
'B':['11110','10001','10001','11110','10001','10001','11110'],
'C':['01111','10000','10000','10000','10000','10000','01111'],
'D':['11110','10001','10001','10001','10001','10001','11110'],
'E':['11111','10000','10000','11110','10000','10000','11111'],
'F':['11111','10000','10000','11110','10000','10000','10000'],
'G':['01111','10000','10000','10111','10001','10001','01111'],
'H':['10001','10001','10001','11111','10001','10001','10001'],
'I':['11111','00100','00100','00100','00100','00100','11111'],
'J':['00111','00010','00010','00010','10010','10010','01100'],
'K':['10001','10010','10100','11000','10100','10010','10001'],
'L':['10000','10000','10000','10000','10000','10000','11111'],
'M':['10001','11011','10101','10101','10001','10001','10001'],
'N':['10001','11001','10101','10011','10001','10001','10001'],
'O':['01110','10001','10001','10001','10001','10001','01110'],
'P':['11110','10001','10001','11110','10000','10000','10000'],
'Q':['01110','10001','10001','10001','10101','10010','01101'],
'R':['11110','10001','10001','11110','10100','10010','10001'],
'S':['01111','10000','10000','01110','00001','00001','11110'],
'T':['11111','00100','00100','00100','00100','00100','00100'],
'U':['10001','10001','10001','10001','10001','10001','01110'],
'V':['10001','10001','10001','10001','10001','01010','00100'],
'W':['10001','10001','10001','10101','10101','10101','01010'],
'X':['10001','10001','01010','00100','01010','10001','10001'],
'Y':['10001','10001','01010','00100','00100','00100','00100'],
'Z':['11111','00001','00010','00100','01000','10000','11111'],
'-':['00000','00000','00000','11111','00000','00000','00000'],
'!':['00100','00100','00100','00100','00100','00000','00100'],
' ':['00000']*7,
}

def pixel_text(im,text,y,scale=2,color='#F4E7C4'):
 clean=text.replace('Ê','E')
 x=(W-(len(clean)*6-1)*scale)//2
 d=ImageDraw.Draw(im)
 for original,ch in zip(text,clean):
  for yy,line in enumerate(GLYPHS[ch]):
   for xx,on in enumerate(line):
    if on=='1': d.rectangle((x+xx*scale,y+yy*scale,x+(xx+1)*scale-1,y+(yy+1)*scale-1),fill=color)
  if original=='Ê':
   d.rectangle((x+scale,y-2*scale,x+2*scale-1,y-scale-1),fill=color)
   d.rectangle((x+3*scale,y-2*scale,x+4*scale-1,y-scale-1),fill=color)
   d.rectangle((x+2*scale,y-3*scale,x+3*scale-1,y-2*scale-1),fill=color)
  x+=6*scale

def background():
 im=Image.new('RGBA',(W,H),'#1D292E');d=ImageDraw.Draw(im)
 # Pixel television housing and inset glass.
 d.rectangle((4,4,635,355),fill='#36454A')
 d.rectangle((9,8,630,342),fill='#111C22')
 d.rectangle((15,14,624,336),fill='#54888D')
 d.rectangle((19,18,620,332),fill='#62999B')
 # Quiet stage backdrop, curtains and stepped wood floor.
 d.rectangle((19,18,47,267),fill='#396A70')
 d.rectangle((594,18,620,267),fill='#396A70')
 for x in (25,35,601,611): d.rectangle((x,18,x+4,267),fill='#315D64')
 d.rectangle((48,98,593,245),fill='#5B9295')
 d.rectangle((48,238,593,245),fill='#3F7379')
 d.rectangle((19,246,620,331),fill='#AD8863')
 d.rectangle((19,246,620,251),fill='#D1AF7C')
 for yy in (273,298,323):
  d.line((19,yy,620,yy),fill='#946F51',width=1)
  offset=48 if yy==298 else 0
  for xx in range(55+offset,620,105):d.line((xx,yy-21,xx,yy),fill='#A07A58',width=1)
 # Low riser for drums, behind the front performers.
 d.rectangle((188,278,329,288),fill='#5B4A3B')
 d.rectangle((184,274,333,279),fill='#C5A06E')
 d.rectangle((184,272,333,274),fill='#E2C091')
 # Welcome message in a consistent bitmap alphabet.
 pixel_text(im,'SEJAM BEM-VINDOS!',40,3,'#254A52')
 pixel_text(im,'SEJAM BEM-VINDOS!',38,3,'#FFF0C9')
 pixel_text(im,'QUE BOM TER VOCÊ AQUI',79,1,'#EFF1DB')
 # Bottom housing and speaker slots.
 for x in range(24,91,7):d.rectangle((x,346,x+3,350),fill='#14272C')
 d.rectangle((606,346,611,351),fill='#F0C772')
 d.rectangle((618,346,623,351),fill='#A7B5A9')
 return im

BG=background()

def cyc(name,elapsed,fps):
 seq=GROUPS[name]
 return seq[int(max(0,elapsed)*fps)%len(seq)]

def once(name,elapsed,duration):
 seq=GROUPS[name]
 return seq[min(len(seq)-1,int(max(0,elapsed)/duration*len(seq)))]

def smooth(q):
 q=max(0,min(1,q));return q*q*(3-2*q)

def place(im,frame,x,y):
 im.alpha_composite(frame.im,(round(x-frame.ax),round(y-frame.ay)))

def render(t):
 im=BG.copy()
 # Back-to-front ordering keeps arriving musicians behind the front row.
 if t>=5:
  if t<9.2:
   x=-140+(228+140)*smooth((t-5)/4.2)
   f=cyc('bateria_entrada',t-5,9)
  elif t<10.4:
   p=min(7,int((t-9.2)/1.2*8))
   x=228+[0,-3,10,25,34,34,32,32][p]
   f=once('bateria_queda',t-9.2,1.2)
  elif t<11.6:
   x=260;f=once('bateria_sentar',t-10.4,1.2)
  else:
   x=260;f=cyc('bateria_tocando',t-11.6,9)
  place(im,f,x,276)
 if t>=16.2:
  if t<21.3:
   x=-200+680*smooth((t-16.2)/5.1)
   f=cyc('teclado_entrada',t-16.2,9)
  elif t<23.1:
   x=480;f=once('teclado_posicionar',t-21.3,1.8)
  else:
   x=480;elapsed=t-23.1
   if int(elapsed/2.5)%2==0:f=cyc('teclado_tocando',elapsed,8)
   else:f=cyc('teclado_cantando',elapsed,8)
  place(im,f,x,316)
 if t>=.8:
  if t<4.4:
   x=-90+215*smooth((t-.8)/3.6);f=cyc('guitarra_andando',t-.8,9)
  else:x=125;f=cyc('guitarra_tocando',t-4.4,8)
  place(im,f,x,322)
 if t>=12.2:
  if t<15.5:
   x=-80+425*smooth((t-12.2)/3.3);f=cyc('voz_andando',t-12.2,9)
  else:x=345;f=cyc('voz_cantando',t-15.5,8)
  place(im,f,x,326)
 return im.convert('RGB')

def samples():
 times=[2.7,7.2,9.8,11.8,14.3,18.5,22.3,27.0]
 panel=Image.new('RGB',(960,540),'#17282D')
 d=ImageDraw.Draw(panel)
 for i,t in enumerate(times):
  p=render(t).resize((320,180),NEAREST)
  x=(i%3)*320;y=(i//3)*180
  panel.paste(p,(x,y))
  d.rectangle((x+4,y+4,x+50,y+18),fill='#17282D')
  d.text((x+8,y+5),f'{t:04.1f}s',fill='white')
 panel.save(ROOT/'conferencia.png')
 render(28).save(ROOT/'cena-final.png')
 print(json.dumps({k:{'frames':len(v),'scale':[round(f.meta['scale'],3) for f in v]} for k,v in GROUPS.items()}),flush=True)

def export():
 mp4=ROOT/'boas-vindas-entrada-dos-musicos.mp4'
 cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size','1280x720','-framerate',str(FPS),'-i','pipe:0','-an','-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(mp4)]
 enc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=subprocess.PIPE)
 try:
  for i in range(DURATION*FPS):
   frame=render(i/FPS).resize((1280,720),NEAREST)
   enc.stdin.write(frame.tobytes())
   if i%(FPS*4)==0:print(f'Video: {i//FPS}/{DURATION}s',flush=True)
  enc.stdin.close()
  err=enc.stderr.read().decode('utf8',errors='replace')
  rc=enc.wait()
  if rc:raise RuntimeError(err)
 except:
  enc.kill();raise
 export_gif()
 print('Export finished',flush=True)

def export_gif():
 # A global palette avoids flashing colors between GIF frames.
 palette=render(28).quantize(colors=160,method=Image.Quantize.MEDIANCUT)
 gifs=[]
 for i in range(DURATION*8):
  frame=render(i/8).quantize(palette=palette,dither=Image.Dither.NONE)
  gifs.append(frame)
 durations=[120 if i%2==0 else 130 for i in range(len(gifs))]
 gifs[0].save(ROOT/'previa-animada.gif',save_all=True,append_images=gifs[1:],duration=durations,loop=0,optimize=True,disposal=1)
 print('GIF finished',flush=True)

samples()
if '--gif-only' in sys.argv:export_gif()
elif '--preview' not in sys.argv:export()
